require 'test_helper'

class InstallationsHelperTest < ActionView::TestCase
end
