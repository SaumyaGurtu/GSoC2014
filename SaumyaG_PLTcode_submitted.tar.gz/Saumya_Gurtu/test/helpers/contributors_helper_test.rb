require 'test_helper'

class ContributorsHelperTest < ActionView::TestCase
end
