require 'test_helper'

class WelcomeHelperTest < ActionView::TestCase
end
